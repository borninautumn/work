# Swiper slide transition

A Pen created on CodePen.io. Original URL: [https://codepen.io/Samuel87/pen/OJJgawb](https://codepen.io/Samuel87/pen/OJJgawb).


